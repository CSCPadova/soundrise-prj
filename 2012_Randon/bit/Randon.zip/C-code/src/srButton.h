#ifndef SRBUTTON_H
#define SRBUTTON_H

#include <math.h>
#include "ofMain.h"
#include "ofxPd.h"
#include "srConstants.h"
#include "srSole.h"

const string button = "Pulsanti/button.png";

class srButton
{
    ofImage imgPulsante;
	ofImage imgButton;
	ofImage imgButtonSelected;
    bool selected;
	int x, y, width, height, index;

    public:
	void setup(string pulsante, int xCord, int yCord, int widthP, int heightP, ofColor selectedColor = ofColor::green, int indexSezione = defaultButton);
        bool pressedButton(int xCord, int yCord, int *selectedButton, srButton &pulsanteSelezionato, ofxPd &pd, srSole &sole);
        bool isSelected();
        void setSelected(bool selected);
        void draw();
		int getId();
		ofImage getImg();
		void update(int xCord, int yCord, int widthP, int heightP);
};

#endif // SRBUTTON_H
