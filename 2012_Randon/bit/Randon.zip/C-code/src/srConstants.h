#ifndef SRCONSTANTS_H_INCLUDED
#define SRCONSTANTS_H_INCLUDED


// costanti delle sezioni
const int intensityAnalisys = 0;
const int pitchAnalisys = 1;
const int durationAnalisys = 2;
const int vowelAnalisys = 3;
const int allAnalisys = 4;

//costanti dei temi
const int Montagna = 0;
const int Mare = 1;
const int Egitto = 2;
const int Citta = 3;

//costante porta OSC
const int OSCport = 9997;



//costante nessun pulsante selezionato
const int noSelectedButton = -2;
//costante pulsante generico
const int defaultButton = -1;

//costante delle viste
const int pageDefault = 0;
const int pageSetting = 1;
const int pagePitchPressed = 2;

#endif // SRCONSTANTS_H_INCLUDED
