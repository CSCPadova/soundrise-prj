/*
 * Copyright (c) 2011 Dan Wilcox <danomatika@gmail.com>
 *
 * BSD Simplified License.
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.
 *
 * See https://github.com/danomatika/ofxPd for documentation
 *
 */
#include "testApp.h"

#include <Poco/Path.h>

//--------------------------------------------------------------
void testApp::setup() {

	ofBackground(127, 127, 127);

	// the number if libpd ticks per buffer,
	// used to compute the audio buffer len: tpb * blocksize (always 64)
	int ticksPerBuffer = 8;	// 8 * 64 = buffer len of 512

#ifdef TARGET_WIN32
	// setup win32 default input device
	inputStream.setDeviceID(2);

	// setup OF sound stream
	inputStream.setup(this, 0, 2, 22050, PdBase::blockSize()*ticksPerBuffer, 2);
	outputStream.setup(this, 2, 0, 22050, PdBase::blockSize()*ticksPerBuffer, 3);
	// setup the app core
	core.setup(2, 2, 22050, ticksPerBuffer);
#else
	// setup OF sound stream
	inputStream.setup(this, 0, 2, 44100, PdBase::blockSize()*ticksPerBuffer, 2);
	outputStream.setup(this, 2, 0, 44100, PdBase::blockSize()*ticksPerBuffer, 3);
	// setup the app core
	core.setup(2, 2, 44100, ticksPerBuffer);
#endif

	//slider
	/*ofSetVerticalSync(true);
	ofEnableSmoothing();

    int red = 233;
    int blue = 27;
    int green = 52;

	float dim = 24;
	float xInit = OFX_UI_GLOBAL_WIDGET_SPACING;
    float length = 320-xInit;

    bool drawPadding = false;

    ofxUICanvas *gui;
    gui = new ofxUICanvas(0, 0, length+xInit, ofGetHeight());
    gui->setFont("fonts/DejaVuSans-Bold.ttf");
    gui->addWidgetDown(new ofxUILabel("SLIDER WIDGETS", OFX_UI_FONT_LARGE));
    gui->addWidgetDown(new ofxUISpacer(length-xInit, 2));
	gui->addWidgetDown(new ofxUILabel("NORMAL SLIDER", OFX_UI_FONT_MEDIUM));
    gui->addWidgetDown(new ofxUISlider(length-xInit,dim, 0.0, 255.0, red, "RED"));

    //ofAddListener(gui->newGUIEvent,this,&testApp::guiEvent);
	ofBackground(red, green, blue);*/
}

//--------------------------------------------------------------
void testApp::update() {
	core.update();
}

//--------------------------------------------------------------
void testApp::draw() {
	core.draw();

	//slider
	ofPushStyle();
	ofEnableBlendMode(OF_BLENDMODE_ALPHA);
	ofPopStyle();
}

//--------------------------------------------------------------
void testApp::exit() {
	core.exit();
}

//--------------------------------------------------------------
void testApp::keyPressed(int key) {
	core.keyPressed(key);
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y) {}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button) {}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button) {
	core.mousePressed(x, y, button);
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button) {}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h) {}

//--------------------------------------------------------------
void testApp::audioReceived(float * input, int bufferSize, int nChannels) {
	core.audioReceived(input, bufferSize, nChannels);
}

//--------------------------------------------------------------
void testApp::audioRequested(float * output, int bufferSize, int nChannels) {
	core.audioRequested(output, bufferSize, nChannels);
}
