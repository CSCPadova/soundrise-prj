/*
 *  sole.cpp
 *  soundrise
 *
 *  Created by Marco Randon on 30/01/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */

#include "srSole.h"

srSole::srSole() {
}

srSole::~srSole() {
	ofRemoveListener(pitchTimer.TIMER_REACHED, this, &srSole::onPitchTimerReached);
	Tweenzor::destroy();
}

void srSole::setup(string sole, string soleSorrisoAperto, string soleSorrisoChiuso) {
	this->scalaAltezza = (int)round(ofGetHeight() / 8.0);
	this->x = ofGetWidth() / 2.0;
	this->y = ofGetHeight() / 2.0 + this->scalaAltezza;
	this->r = 0;
	this->sezione = intensityAnalisys;
	this->voiceOn = false;
	this->imgSole.loadImage(sole);
	this->imgSole.resize(256, 256);
	this->imgSoleSorrisoAperto.loadImage(soleSorrisoAperto);
	this->imgSoleSorrisoAperto.resize(256, 256);
	this->imgSoleSorrisoChiuso.loadImage(soleSorrisoChiuso);
	this->imgSoleSorrisoChiuso.resize(256, 256);

    //Utilizzo addon Tweenzor per effetto transizione colore sole
    Tweenzor::init();  // must call this before adding any tweens
    //giallo del sole
    sunColor_r = 255.f;
    sunColor_g = 255.f;
    sunColor_b = 0.f;
    //verde per la vocale E
    E_color.r = 0.f;
    E_color.g = 255.f;
    E_color.b = 0.f;
    //rosso per la vocale A
    A_color.r = 255.f;
    A_color.g = 0.f;
    A_color.b = 0.f;
    //arancione per la vocale O
    O_color.r = 255.f;
    O_color.g = 120.f;
    O_color.b = 0.f;
    //blu per la vocale I
    I_color.r = 0.f;
    I_color.g = 0.f;
    I_color.b = 255.f;
    //grigio per la vocale U
    U_color.r = 120.f;
    U_color.g = 120.f;
    U_color.b = 120.f;
    //colore giallo per il default
    default_color.r = 255.f;
    default_color.g = 255.f;
    default_color.b = 0.f;

    //Iscrizione all'evento TIMER_REACHED
    ofAddListener(pitchTimer.TIMER_REACHED, this, &srSole::onPitchTimerReached);

}

void srSole::update(){
    Tweenzor::update(ofGetElapsedTimeMillis());
    //ricalcolo posizionamento e dimensione del soleS
    this->scalaAltezza = (int)round(ofGetHeight() / 8.0);
	this->x = ofGetWidth() / 2.0;
	if (!isPichAnalysed) this->y = ofGetHeight() / 2.0 - this->scalaAltezza;
	//this->r = this->scalaAltezza;
}

float srSole::getAltezza() { //valori uscita nel range [-1, 3]
	return (float)((this->y - (ofGetHeight() / 2.0)) / (2.0 * this->scalaAltezza));
}

float srSole::getIntensita() { //valori uscita nel range [1, 3]
	return (float)this->r;
}

float srSole::getSezione() {
	return (float)this->sezione;
}

void srSole::setAltezza(float altezza) { //valori ingresso nel range [-1, 3]
	this->y = (ofGetHeight() / 2.0) - (altezza * this->scalaAltezza);
}

void srSole::setIntensita(float intensita) { //valori ingresso nel range [1, 3]
	this->r = intensita * (this->scalaAltezza / 2.0);
}

void srSole::setSezione(float sezione) {
	this->sezione = (int)trunc(sezione);
	//resetto il sole (posizione e dimensione iniziali)
	this->y = ofGetHeight() / 2.0; //+ this->scalaAltezza;
	if (sezione == durationAnalisys) this->r = this->scalaAltezza; //sole a met� altezza
	else this->r = 0; //sole non visibile
}

void srSole::setVoiceOn(float voiceOn) {
	switch (this->sezione) {
		case allAnalisys:
            isPichAnalysed =true;
            this->voiceOn = voiceOn;
			break;
		case durationAnalisys:
            isPichAnalysed =false;
			this->voiceOn = voiceOn;
			break;
		case vowelAnalisys:
            cout << "vowelAnalisys" << endl;
		case pitchAnalisys:
            cout << "pitchAnalisys" << endl;
            isPichAnalysed =true;
			if (voiceOn == true) {
				pitchTimer.setup(100, false);
			}
			else this->r = 0;
			break;
		case intensityAnalisys:
            isPichAnalysed =false;
			cout << "intensityAnalisys" << endl;
			this->r = this->r * (int)voiceOn;
			break;
     	default:
			break;
	}
}

void srSole::setVocale(int vocale) {
	setVocale(vocale, 1.0);
}

void srSole::setVocale(int vocale, float confidenza) {
	this->alpha = confidenza;
	switch (vocale){
	    case vocaleE:
            this->colore = verde;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, E_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, E_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, E_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
	    case vocaleA:
            this->colore = rosso;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, A_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, A_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, A_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
	    case vocaleO:
            this->colore = arancione;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, O_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, O_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, O_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
	    case vocaleI:
            this->colore = blu;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, I_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, I_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, I_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
	    case vocaleU:
            this->colore = grigio;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, U_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, U_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, U_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
        case silenzio:
            this->colore = giallo;
            Tweenzor::removeAllTweens();
            // add a tween that uses frames as time
            Tweenzor::add(&sunColor_r, sunColor_r, default_color.r, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_g, sunColor_g, default_color.g, 0.f, tempo_TransColor);
            Tweenzor::add(&sunColor_b, sunColor_b, default_color.b, 0.f, tempo_TransColor);
            Tweenzor::getTween(&sunColor_r)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_g)->setRepeat(1, true);
            Tweenzor::getTween(&sunColor_b)->setRepeat(1, true);
            break;
	}
}


void srSole::draw() {

	ofPushStyle();
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_ADD);
	ofEnableBlendMode(OF_BLENDMODE_ADD);
	//Abilito la trasparenza per poter settare a 255 l'alpha
	ofEnableAlphaBlending();
	ofSetColor(255, 255, 0, 255);
	if (this->sezione == vowelAnalisys) isPichAnalysed = false;
	if ((this->sezione == vowelAnalisys) || (this->sezione == allAnalisys)) {
        switch(this->colore){
            case verde:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
            case rosso:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
            case arancione:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
            case blu:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
            case grigio:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
            case giallo:
                ofSetColor(sunColor_r, sunColor_g, sunColor_b);
                break;
        }
	}

#ifdef TARGET_OPENGLES

	this->imgSole.getTextureReference().bind();
	GLfloat vertici[] = {
		x - r, y - r,
		x + r, y - r,
		x - r, y + r,
		x + r, y - r,
		x + r, y + r,
		x - r, y + r
	 };
	 GLfloat texCoords[] = {
	 0.0, 0.0,
	 1.0, 0.0,
	 0.0, 1.0,
	 1.0, 0.0,
	 1.0, 1.0,
	 0.0, 1.0
	 };

	/*
	//errore nel calcolo dei vertici
	ofPolyline cerchio;
	vector<ofPoint> & cerchioCache = cerchio.getVertices();
	GLfloat puntiCerchio[2*(int)cerchioCache.size()];
	for (int i = 0; i < (int)cerchioCache.size(); i++) {
		puntiCerchio[2*i] = cerchioCache[i].x;
		puntiCerchio[2*i+1] = cerchioCache[i].y;
	}
	cout << puntiCerchio[3] << endl;
	*/

    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer(2, GL_FLOAT, /*sizeof(ofVec3f)*/0, /*puntiCerchio*/texCoords );
	glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, vertici);
	glDrawArrays(GL_TRIANGLES, 0, 6);
	this->imgSole.getTextureReference().unbind();

	if ((this->sezione == durationAnalisys) || (this->sezione == allAnalisys)) {
		ofSetColor(0, 0, 0, 255);
		if (this->voiceOn) {
			this->imgSoleSorrisoAperto.getTextureReference().bind();
			glTexCoordPointer(2, GL_FLOAT, /*sizeof(ofVec3f)*/0, /*puntiCerchio*/texCoords );
			glDrawArrays(GL_TRIANGLES, 0, 6);
			this->imgSoleSorrisoAperto.getTextureReference().unbind();
		} else {
			this->imgSoleSorrisoChiuso.getTextureReference().bind();
			glTexCoordPointer(2, GL_FLOAT, /*sizeof(ofVec3f)*/0, /*puntiCerchio*/texCoords );
            glDrawArrays(GL_TRIANGLES, 0, 6);
			this->imgSoleSorrisoChiuso.getTextureReference().unbind();
		}
	}

	glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

#else //OPENGL

	this->imgSole.draw(x-r, y-r, 2*r, 2*r);
    if ((this->sezione == durationAnalisys) || (this->sezione == allAnalisys)) {
		ofSetColor(0, 0, 0, 255);
		if (this->voiceOn) {
			this->imgSoleSorrisoAperto.draw(x-r, y-r, 2*r, 2*r);
		} else {
			this->imgSoleSorrisoChiuso.draw(x-r, y-r, 2*r, 2*r);
		}
	}

#endif

	ofDisableAlphaBlending();
	ofDisableBlendMode();
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	ofPopStyle();
}

void srSole::onPitchTimerReached(ofEventArgs &args) {
    this->r = this->scalaAltezza;
}


