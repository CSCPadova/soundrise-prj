/*
 *  sole.h
 *  soundrise
 *
 *  Created by Marco Randon on 30/01/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef __SOUNDRISE_SOLE_
#define __SOUNDRISE_SOLE_

#include <math.h>
#include "ofMain.h"
#include "ofxTweenzor.h"
#include "srConstants.h"
#include "ofxTimer.h"

// costanti delle vocali
const int vocaleA = 0;
const int vocaleE = 1;
const int vocaleI = 2;
const int vocaleO = 3;
const int vocaleU = 4;
const int silenzio = 5;

//costanti dei colori
const int verde = 0;
const int rosso = 1;
const int arancione = 2;
const int blu = 3;
const int grigio = 4;
const int giallo = 5;

//Tempo di transizione da un colore ad un altro
const float tempo_TransColor = 1.0f;


class srSole {
	int x, y, r, colore;
	float alpha;
	int sezione;
	bool voiceOn;
	int scalaAltezza;
	ofImage imgSole, imgSoleSorrisoAperto, imgSoleSorrisoChiuso;
    float sunColor_r, sunColor_g, sunColor_b;
	ofColor E_color;
	ofColor A_color;
	ofColor O_color;
	ofColor I_color;
	ofColor U_color;
	ofColor default_color;
	//Timer ritardo visualizzazione sole in pitch analisys per far apparire il sole direttamente alla posizione del tono emesso
    ofxTimer pitchTimer;
    bool isPichAnalysed;

public:
	srSole();
	~srSole();
	void setup(string sole, string soleSorrisoAperto, string soleSorrisoChiuso);
	float getAltezza();
	float getIntensita();
	float getSezione();
	void setAltezza(float altezza);
	void setIntensita(float intensita);
	void setSezione(float sezione);
	void setVoiceOn(float voiceOn);
	void setVocale(int vocale);
	void setVocale(int vocale, float confidenza);
	void draw();
    void update();
    // pitch callback
    void onPitchTimerReached(ofEventArgs &args);
};

#endif /*__SOUNDRISE_SOLE_*/
