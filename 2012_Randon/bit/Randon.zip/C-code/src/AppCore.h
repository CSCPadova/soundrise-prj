/*
 * Copyright (c) 2011 Dan Wilcox <danomatika@gmail.com>
 *
 * BSD Simplified License.
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.
 *
 * See https://github.com/danomatika/ofxPd for documentation
 *
 */
#pragma once

#include "ofMain.h"

#include "ofxPd.h"

#include "srSole.h"

#include "srButton.h"

#include <vector>

#include "srConstants.h"

#include "ofxTimer.h"

#ifndef TARGET_OF_IPHONE || TARGET_ANDROID
#include "ofxOsc.h"
#endif

using namespace pd;

class AppCore : public PdReceiver, public PdMidiReceiver {

	public:

		// main
		void setup(const int numOutChannels, const int numInChannels,
				   const int sampleRate, const int ticksPerBuffer);
		void update();
		void draw();
        void exit();

		// do something
		void playTone(int pitch);

		// input callbacks
		void keyPressed(int key);

		// audio callbacks
		void audioReceived(float * input, int bufferSize, int nChannels);
		void audioRequested(float * output, int bufferSize, int nChannels);

		// pd callbacks
		void print(const std::string& message);

		void receiveBang(const std::string& dest);
		void receiveFloat(const std::string& dest, float value);
		void receiveSymbol(const std::string& dest, const std::string& symbol);
		void receiveList(const std::string& dest, const List& list);
		void receiveMessage(const std::string& dest, const std::string& msg, const List& list);

		void receiveNoteOn(const int channel, const int pitch, const int velocity);
		void receiveControlChange(const int channel, const int controller, const int value);
		void receiveProgramChange(const int channel, const int value);
		void receivePitchBend(const int channel, const int value);
		void receiveAftertouch(const int channel, const int value);
		void receivePolyAftertouch(const int channel, const int pitch, const int value);

		void receiveMidiByte(const int port, const int byte);

		// touch callbacks
		void touchDown(ofTouchEventArgs &touch);

		// mouse callbacks
		void mousePressed(int x, int y, int button);

		// tone callback
		void onToneTimerReached(ofEventArgs &args);

		ofxPd pd;
		ofTrueTypeFont font;
		ofImage imgSfondoBack;
		vector<ofImage> imgSfondoFront;
		int indexSfondo;
	
		srSole sole;
		//Timer setting tono medio
        ofxTimer toneTimer;

		//-----Parte relativa all'interfaccia (pulsanti)-----//
		vector<srButton> pulsanti; //qui il vettore non pu� essere inizializzato
		//costruttore. In AppCore.cpp viene poi inizializzato il vettore nel costruttore
		AppCore();
		//distanza pulsante dal bordo destro della finestra
		int distX_Pulsanti;
		//distanza aggiuntiva tra un pulsante e l'altro
		int distY_Pulsanti;
		//dimensioni pulsanti
		int pulsanteWidth, pulsanteHeight;
		//distanza tra le anteprime dei temi
		int distX_Temi;
		//ampiezza barra pulsanti verticale
		int widthVertBar;
        //ampiezza barra pulsanti orizzontale
        int widthOrizBar;
        //altezza barra pulsanti orizzontale
        int heightOrizBar;
        //indice pulsante selezionato
        int selectedButton;
        //variabile indice vista
        int page;
		//variabile di memorizzazione scala altezza
		int switchScala;
		//variabile per spostare i pulsanti switchScala tra il pulsante pitchAnalisys e allAnalisys
		int offSetBtnScala;
		//memorizzo lo stato di voiceON
		bool voiceON;


#ifndef TARGET_OF_IPHONE || TARGET_ANDROID
		// OSC/UDP
		ofxOscReceiver OSCreceiver;
#endif

};
