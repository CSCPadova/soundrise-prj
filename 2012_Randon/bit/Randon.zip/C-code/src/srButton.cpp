#include "srButton.h"

void srButton::setup(string pulsante, int xCord, int yCord, int widthP, int heightP, ofColor selectedColor, int indexSezione){

    //identificativo sezione
	this->index = indexSezione;
	//dimensione pulsante sezioni
    this->width = widthP;
    this->height = heightP;
    //coordinate pulsante sezioni
    this->x = xCord;
    this->y = yCord;
    //il pulsante viene settato come non selezionato
    this->selected = false;
    //carico l'immagine del pulsante
    this->imgPulsante.loadImage(pulsante);
    //carico l'immagine button che crea l'effetto del pulsante
	this->imgButton.loadImage(button);
    ofImage imgTemp = this->imgPulsante;
    imgTemp.crop((imgTemp.getWidth() - imgTemp.getHeight()) / 4, 0, imgTemp.getHeight(), imgTemp.getHeight());
    imgTemp.resize(this->imgButton.getWidth(), this->imgButton.getHeight());
    //imgTemp.getPixelsRef().resize(this->imgButton.getWidth(), this->imgButton.getHeight());
    imgTemp.update();
    ofColor buttonColor;
	for(int i = 0; i < this->imgButton.getWidth(); i++){
	    for(int j = 0; j < this->imgButton.getHeight(); j++){
            buttonColor = this->imgButton.getColor(i, j) * imgTemp.getColor(i, j);
            buttonColor.a = this->imgButton.getColor(i, j).a;
            this->imgButton.setColor(i, j, buttonColor);
	    }
	}
	this->imgButton.update();
	// immagine che crea l'effetto della selezione del pulsante
    this->imgButtonSelected = this->imgButton;
    ofColor buttonSelectedColor;
    //tempColor.set(178, 255, 178, 255);
    for(int i = 0; i < this->imgButtonSelected.getWidth(); i++){
	    for(int j = 0; j < this->imgButtonSelected.getHeight(); j++){
            buttonSelectedColor = this->imgButtonSelected.getColor(i, j) * selectedColor;
            //buttonSelectedColor.g = this->imgButtonSelected.getColor(i, j).g;
            //buttonSelectedColor.b = this->imgButtonSelected.getColor(i, j).b * 0.7;
            buttonSelectedColor.a = this->imgButtonSelected.getColor(i, j).a;
            this->imgButtonSelected.setColor(i, j, buttonSelectedColor);
	    }
	}
	this->imgButtonSelected.update();
}

void srButton::update(int xCord, int yCord, int widthP, int heightP){
    this->width = widthP;
    this->height = heightP;
    //coordinate pulsante sezioni
    this->x = xCord;
    this->y = yCord;
}

//controlla quale pulsante relativo alla sezione � stato cliccato
bool srButton::pressedButton(int xCord, int yCord, int *selectedButton, srButton &pulsanteSelezionato, ofxPd &pd, srSole &sole){
    if(xCord > this->x && xCord < this->x+this->width && yCord > this->y && yCord < this->y+this->height){ //se sono stato premuto
        if (this->index != defaultButton){ //se sono un pulsante sezione
            if (*selectedButton == this->index){ //se ero gi� selezionato mi deseleziono
                sole.setIntensita(0);
                this->selected = false;
                *selectedButton = noSelectedButton;
                return true;
            }
            if (*selectedButton == noSelectedButton){ //se non c'era un altro pulsante selezionato
                    this->selected = true;
                    *selectedButton = this->index;
            }
            else{ //se c'era un altro pulsante selezionato
                pulsanteSelezionato.setSelected(false);
                this->selected = true;
                *selectedButton = this->index;
            }

            /*if(!selected) this->selected = true;
            else this->selected = false;*/
            return true;
        }
        else{ //sono un pulsante generico
            return true;
        }
    }
    else return false;
}

void srButton::setSelected(bool selected){
    this->selected = selected;
}


bool srButton::isSelected(){
    return this->selected;
}

void srButton::draw(){

    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_ADD);
	ofEnableBlendMode(OF_BLENDMODE_ADD);
	//Abilito la trasparenza per poter settare a 255 l'alpha
	ofEnableAlphaBlending();

	ofSetColor(0, 0, 0, 255);
	if (!selected) this->imgButton.draw(x, y, height, height);
    else this->imgButtonSelected.draw(x, y, height, height);//evidenzio il pulsante selezionato

	ofDisableAlphaBlending();
	ofDisableBlendMode();
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

int srButton::getId() {
	return this->index;
}

ofImage srButton::getImg() {
	return this->imgPulsante;
}
