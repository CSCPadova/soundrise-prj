/*
 * Copyright (c) 2011 Dan Wilcox <danomatika@gmail.com>
 *
 * BSD Simplified License.
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.
 *
 * See https://github.com/danomatika/ofxPd for documentation
 *
 */
#include "AppCore.h"

#include <Poco/Path.h>

//diciamo al compilatore di cercare funzioni C (non C++)
extern "C"{
	void counter_setup();
	void bfcc_tilde_setup();
	void mfcc_setup();
	void timbreID_setup();
	void isteresi_setup();
	void fiddle_setup();
	void portaNOT_setup();
	void normalizer2_setup();
}

// costanti
const bool filtroON = false; //filtroON=false ==> filtro attivo
const int scalaAssoluta = 0;
const int scalaRelativa = 1;


//Serve inizializzare il vettore "pulsanti" nel costruttore
AppCore::AppCore() {
    // Now testArray will have 16 entries.
	pulsanti = vector<srButton>(16);
	imgSfondoFront = vector<ofImage>(4);
}
//--------------------------------------------------------------
void AppCore::setup(const int numOutChannels, const int numInChannels,
				    const int sampleRate, const int ticksPerBuffer) {

    ofSetFrameRate(60);
	ofSetVerticalSync(true);
	//ofSetLogLevel(OF_LOG_VERBOSE);

	//seleziono la view
	page = pageDefault;
	
	//imposto la scala assoluta delle altezze all'avvio
	switchScala = scalaAssoluta;
	
	//inizializzo voiceON
	voiceON = false;

#ifdef TARGET_OSX
	ofSetDataPathRoot("../Resources/data/");
#endif
	
#ifdef TARGET_OF_IPHONE || TARGET_ANDROID
	font.loadFont("fonts/UnDotum.ttf", 11);
#else
	font.loadFont("fonts/UnDotum.ttf", 20);
#endif

	if(!pd.init(numOutChannels, numInChannels, sampleRate, ticksPerBuffer)) {
		ofLog(OF_LOG_ERROR, "Could not init pd");
		OF_EXIT_APP(1);
	}

	// add recieve source names
	pd.subscribe("vocale");
	pd.subscribe("PITCH");
	pd.subscribe("voiceON");
	pd.subscribe("POWER");
	pd.subscribe("sezione");
	pd.subscribe("setSoglia");

	// add listener
	pd.addReceiver(*this);

	// add the data/pd folder to the search path
	pd.addToSearchPath("pd");

	//setup degli external
	counter_setup();
	bfcc_tilde_setup();
	mfcc_setup();
	timbreID_setup();
	isteresi_setup();
	fiddle_setup();
	portaNOT_setup();
	normalizer2_setup();

	// audio processing on
	pd.start();

	// open patch
	//Patch patch = pd.openPatch("pseudoCore.pd");
	Patch patch = pd.openPatch("SoundRiseCore.pd");
	cout << patch << endl;

	// inizializzazione patch
	pd.sendBang("setCore");
	pd.sendFloat("filtroON", !filtroON);
	pd.sendFloat("maxPitch", 68);
	pd.sendFloat("maxIntensity", 140);
	pd.sendFloat("switchScala", 0);

	//pd.sendFloat("sezione", 2);

	imgSfondoBack.loadImage("Temi/MontagnaBack.png");
	imgSfondoFront[0].loadImage("Temi/MontagnaFront.png");
	imgSfondoFront[1].loadImage("Temi/MareFront.png");
	imgSfondoFront[2].loadImage("Temi/EgittoFront.png");
	imgSfondoFront[3].loadImage("Temi/Citta'Front.png");
	
	sole.setup("Sole/Sole.png", "Sole/Sole_sorrisoAperto.png", "Sole/Sole_sorrisoChiuso.png");
	//pd.sendFloat("sezione", (float)pitchAnalisys);

#ifndef TARGET_OF_IPHONE || TARGET_ANDROID
	//attivazione server OSC
	OSCreceiver.setup(OSCport);
#endif

    selectedButton = noSelectedButton;
    //dimensione pulsanti e barre interfaccia
    pulsanteWidth = ofGetWidth() / 12;
    pulsanteHeight = pulsanteWidth;
    widthVertBar = pulsanteWidth + 14;
    distX_Pulsanti = (widthVertBar - pulsanteWidth) / 2;
    distY_Pulsanti = ofGetHeight() / 30;
    distX_Temi = ofGetWidth() / 20;
    heightOrizBar = pulsanteHeight;
    widthOrizBar = ofGetWidth() - widthVertBar;

    pulsanti[0].setup("Pulsanti/Sezione0.png", ofGetWidth() - pulsanteWidth - distX_Pulsanti, distY_Pulsanti, pulsanteWidth, pulsanteHeight, ofColor::green, intensityAnalisys);
    pulsanti[1].setup("Pulsanti/Sezione1.png", ofGetWidth() - pulsanteWidth - distX_Pulsanti, pulsanteHeight + 2*distY_Pulsanti, pulsanteWidth, pulsanteHeight, ofColor::green, pitchAnalisys);
    pulsanti[2].setup("Pulsanti/Sezione2.png", ofGetWidth() - pulsanteWidth - distX_Pulsanti, 2*pulsanteHeight + 3*distY_Pulsanti, pulsanteWidth, pulsanteHeight, ofColor::green, durationAnalisys);
    pulsanti[3].setup("Pulsanti/Sezione3.png", ofGetWidth() - pulsanteWidth - distX_Pulsanti, 3*pulsanteHeight + 4*distY_Pulsanti, pulsanteWidth, pulsanteHeight, ofColor::green, vowelAnalisys);
    pulsanti[4].setup("Pulsanti/Sezione4.png", ofGetWidth() - pulsanteWidth - distX_Pulsanti, 4*pulsanteHeight + 5*distY_Pulsanti, pulsanteWidth, pulsanteHeight, ofColor::green, allAnalisys);
    pulsanti[5].setup("Temi/MontagnaBack.png", distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[6].setup("Temi/MareBack.png", pulsanteWidth + 2.5*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[7].setup("Temi/EgittoBack.png", 2*pulsanteWidth + 4*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[8].setup("Temi/Citta'Back.png", 3*pulsanteWidth + 5.5*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
	pulsanti[9].setup("Pulsanti/Refresh.png", widthOrizBar - pulsanteWidth, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight, ofColor::red);
	//pulsanti[10].setup("", widthOrizBar, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
	pulsanti[11].setup("Pulsanti/PitchSetting.png", widthOrizBar - 2*pulsanteWidth - distX_Pulsanti, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[12].setup("Pulsanti/Tono.png",distX_Temi, ofGetHeight() / 2, pulsanteWidth, pulsanteHeight);
    pulsanti[13].setup("Pulsanti/Ok.png", pulsanteWidth + 2.5*distX_Temi, ofGetHeight() / 2, pulsanteWidth, pulsanteHeight);
    pulsanti[14].setup("Pulsanti/ScalaA.png", ofGetWidth() - 1.6*pulsanteWidth, pulsanteHeight + 2*distY_Pulsanti, pulsanteWidth/2, pulsanteHeight/2);
    pulsanti[15].setup("Pulsanti/ScalaR.png", ofGetWidth() - 1.6*pulsanteWidth, 1.5*pulsanteHeight + 2*distY_Pulsanti, pulsanteWidth/2, pulsanteHeight/2);

    //Iscrizione all'evento TIMER_REACHED
    ofAddListener(toneTimer.TIMER_REACHED, this, &AppCore::onToneTimerReached);

	//pd.sendFloat("openAndrea", 1);
	//pd.sendFloat("startAif", 1);
}

//--------------------------------------------------------------
void AppCore::update() {

    pulsanti[0].update(ofGetWidth() - pulsanteWidth - distX_Pulsanti, distY_Pulsanti, pulsanteWidth, pulsanteHeight);
    pulsanti[1].update(ofGetWidth() - pulsanteWidth - distX_Pulsanti, pulsanteHeight + 2*distY_Pulsanti, pulsanteWidth, pulsanteHeight);
    pulsanti[2].update(ofGetWidth() - pulsanteWidth - distX_Pulsanti, 2*pulsanteHeight + 3*distY_Pulsanti, pulsanteWidth, pulsanteHeight);
    pulsanti[3].update(ofGetWidth() - pulsanteWidth - distX_Pulsanti, 3*pulsanteHeight + 4*distY_Pulsanti, pulsanteWidth, pulsanteHeight);
    pulsanti[4].update(ofGetWidth() - pulsanteWidth - distX_Pulsanti, 4*pulsanteHeight + 5*distY_Pulsanti, pulsanteWidth, pulsanteHeight);
    pulsanti[5].update(distX_Temi,  ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[6].update(pulsanteWidth + 2.5*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[7].update(2*pulsanteWidth + 4*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[8].update(3*pulsanteWidth + 5.5*distX_Temi, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[9].update(ofGetWidth() - widthVertBar - pulsanteWidth, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
	//pulsanti[10].update(ofGetWidth() - widthVertBar + distX_Pulsanti, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
	pulsanti[11].update(ofGetWidth() - widthVertBar - 2*pulsanteWidth - distX_Pulsanti, ofGetHeight() - pulsanteHeight, pulsanteWidth, pulsanteHeight);
    pulsanti[12].update(distX_Temi, ofGetHeight() / 2, pulsanteWidth, pulsanteHeight);
    pulsanti[13].update(pulsanteWidth + 2.5*distX_Temi, ofGetHeight() / 2, pulsanteWidth, pulsanteHeight);
    pulsanti[14].update(ofGetWidth() - 1.6*pulsanteWidth, pulsanteHeight + 2*distY_Pulsanti + offSetBtnScala, pulsanteWidth/2, pulsanteHeight/2);
    pulsanti[15].update(ofGetWidth() - 1.6*pulsanteWidth, 1.5*pulsanteHeight + 2*distY_Pulsanti + offSetBtnScala, pulsanteWidth/2, pulsanteHeight/2);

	ofBackground(100, 100, 100);
	sole.update();

#ifndef TARGET_OF_IPHONE || TARGET_ANDROID
	while(OSCreceiver.hasWaitingMessages()){
        ofxOscMessage OSCmsg;
        OSCreceiver.getNextMessage(&OSCmsg);
        if(strcmp(OSCmsg.getAddress().c_str(), "/num") == 0){
            int sez = -1;
            switch(OSCmsg.getArgType(0)){
            case OFXOSC_TYPE_INT32:
                sez = OSCmsg.getArgAsInt32(0);
                break;
            case OFXOSC_TYPE_FLOAT:
                sez = (int)OSCmsg.getArgAsFloat(0);
                break;
            default:
                cout << "Messaggio OSC non riconosciuto!" << endl;
                break;
            }
            switch(sez){
            case 2:
                sez = 0;
                break;
            case 4:
                sez = 1;
                break;
            case 6:
                sez = 2;
                break;
            case 8:
                sez = 3;
                break;
            case 9:
                sez = 4;
                break;
            default:
                sez = -1;
                break;
            }
        if(sez != -1) pd.sendFloat("sezione", sez);
        }
    }
#endif
}

//--------------------------------------------------------------
void AppCore::draw() {

	/*	Pulsante soglia (sendBang("newSoglia");)
	 *	Selettore SEZIONE (sendFloat(int sez, "sezione");)
	 *	Controllo INTENSITY (sendFloat(float intensity, "maxIntensity");) [bottom=120; top=80]
	 *	Controllo SCALA_PITCH (sendFloat(float maxPitch, "maxPitch");) [bottom=100; top=50]
	 *	Selettore filtroON (sendFloat(int filtroON=0 OR int filtroOFF=1, "filtroON");)
	 */

	ofSetColor(255, 255, 255);
	imgSfondoBack.draw(0, 0, ofGetWidth(), ofGetHeight());

	if (selectedButton != noSelectedButton) sole.draw();
	
	ofEnableAlphaBlending();
	imgSfondoFront[indexSfondo].draw(0, 0, ofGetWidth(), ofGetHeight());

	//gestione delle view
	switch(page){
        case pageDefault:
            //barra grigia che contiene i pulsanti
            ofEnableAlphaBlending();
            ofSetColor(120, 120, 120, 130);
            //barra pulsanti verticale
            ofRect(ofGetWidth() - widthVertBar, 0, widthVertBar, ofGetHeight());
            //barra pulsanti orizzontale
            ofRect(0, ofGetHeight() - pulsanteHeight, ofGetWidth() - widthVertBar, heightOrizBar);
            ofDisableAlphaBlending();
            pulsanti[0].draw();
            pulsanti[1].draw();
            pulsanti[2].draw();
            pulsanti[3].draw();
            pulsanti[4].draw();
            pulsanti[5].draw();
            pulsanti[6].draw();
            pulsanti[7].draw();
            pulsanti[8].draw();
            pulsanti[9].draw();
            //pulsanti[10].draw();
            pulsanti[11].draw();
            break;
        case pageSetting:
            ofEnableAlphaBlending();
            ofSetColor(120, 120, 120, 130);
            //barra desrizione funzionamento setting
#ifdef TARGET_OF_IPHONE || TARGET_ANDROID
            ofRect(0, 0, 20 + font.stringWidth("Premere OK per uscire dalla\n"), ofGetHeight());
            ofDisableAlphaBlending();
            ofSetColor(255, 0, 0);
            font.drawString("Premi il pulsante con il\n" 
							"profilo della faccia e\n"
							"produci con la voce una A\n"
							"lunga fino a quando\n"
							"il pulsante non si spegne.\n\n"
                            "Premere OK per uscire dalla\n"
                            "schermata di settings.", 10, 20);
#else
			ofRect(0, 0, 30 + font.stringWidth("Premere OK per uscire dalla\n"), ofGetHeight());
            ofDisableAlphaBlending();
            ofSetColor(255, 0, 0);
			font.drawString("Premi il pulsante con il\n" 
							"profilo della faccia e\n"
							"produci con la voce una A\n"
							"lunga fino a quando\n"
							"il pulsante non si spegne.\n\n"
                            "Premere OK per uscire dalla\n"
                            "schermata di settings.", 15, 30);
#endif
            pulsanti[12].draw();
            pulsanti[13].draw();
            break;
        case pagePitchPressed:
            //barra grigia che contiene i pulsanti
            ofEnableAlphaBlending();
            ofSetColor(120, 120, 120, 130);
            //barra pulsanti verticale
            ofRect(ofGetWidth() - widthVertBar, 0, widthVertBar, ofGetHeight());
            //barra pulsanti orizzontale
            ofRect(0, ofGetHeight() - pulsanteHeight, ofGetWidth() - widthVertBar, heightOrizBar);
            ofDisableAlphaBlending();
            pulsanti[0].draw();
            pulsanti[1].draw();
            pulsanti[2].draw();
            pulsanti[3].draw();
            pulsanti[4].draw();
            pulsanti[5].draw();
            pulsanti[6].draw();
            pulsanti[7].draw();
            pulsanti[8].draw();
            pulsanti[9].draw();
            //pulsanti[10].draw();
            pulsanti[11].draw();
            pulsanti[14].draw();
            pulsanti[15].draw();

	}

}

//--------------------------------------------------------------
void AppCore::exit() {
    pd.closePatch("SoundRiseCore.pd");
    ofRemoveListener(toneTimer.TIMER_REACHED, this, &AppCore::onToneTimerReached);
}

//--------------------------------------------------------------
void AppCore::playTone(int pitch) {
	pd << StartMessage() << "pitch" << pitch << FinishList("tone") << Bang("tone");
}

//--------------------------------------------------------------
void AppCore::keyPressed (int key) {

	switch(key) {

		case 'a':
			playTone(60);
			break;
		case 'w':
			playTone(61);
			break;
		case 's':
			playTone(62);
			break;
		case 'e':
			playTone(63);
			break;
		case 'd':
			playTone(64);
			break;
		case 'f':
			playTone(65);
			break;
		case 't':
			playTone(66);
			break;
		case 'g':
			playTone(67);
			break;
		case 'y':
			playTone(68);
			break;
		case 'h':
			playTone(69);
			break;
		case 'u':
			playTone(70);
			break;
		case 'j':
			playTone(71);
			break;
		case 'k':
			playTone(72);
			break;

		case ' ':
			if(pd.isReceiving(*this, "env")) {
				pd.ignore(*this, "env");
			}
			else {
				pd.receive(*this, "env");
			}
			break;

		default:
			break;
	}
}

//--------------------------------------------------------------
void AppCore::audioReceived(float * input, int bufferSize, int nChannels) {
	pd.audioIn(input, bufferSize, nChannels);
}

//--------------------------------------------------------------
void AppCore::audioRequested(float * output, int bufferSize, int nChannels) {
	pd.audioOut(output, bufferSize, nChannels);
}

//--------------------------------------------------------------
void AppCore::print(const std::string& message) {
	cout << message << endl;
}

//--------------------------------------------------------------
void AppCore::receiveBang(const std::string& dest) {
	cout << "OF: bang " << dest << endl;
}

void AppCore::receiveFloat(const std::string& dest, float value) {
	cout << "OF: float " << dest << ": " << value << endl;
	if (dest.compare("PITCH") == 0) {
		sole.setAltezza(value);
	} else if (dest.compare("voiceON") == 0) {
		sole.setVoiceOn(value);
		voiceON = value;
	} else if (dest.compare("POWER") == 0) {
		sole.setIntensita(value);
	} else if (dest.compare("sezione") == 0) {
		sole.setSezione(value);
		sole.setVoiceOn(voiceON);
    }
}

void AppCore::receiveSymbol(const std::string& dest, const std::string& symbol) {
	cout << "OF: symbol " << dest << ": " << symbol << endl;
}

void AppCore::receiveList(const std::string& dest, const List& list) {
	cout << "OF: list " << dest << ": " << list << endl;

	if (dest.compare("vocale") == 0) {
		sole.setVocale(list.getFloat(0), list.getFloat(1));
	}

/*	// step through the list
	for(int i = 0; i < list.len(); ++i) {
		if(list.isFloat(i))
			cout << list.getFloat(i) << " ";
		else if(list.isSymbol(i))
			cout << list.asSymbol(i) << " ";
	}


    // you can also use the built in toString function or simply stream it out
    // cout << list.toString();
    // cout << list;

    // print an OSC-style type string
	cout << list.types() << endl;
 */
}

void AppCore::receiveMessage(const std::string& dest, const std::string& msg, const List& list) {
	cout << "OF: msg " << dest << ": " << msg << " " << list.toString() << list.types() << endl;
	if (dest.compare("setSoglia") == 0) {
		pulsanti[9].setSelected(false);
	}
}

//--------------------------------------------------------------
void AppCore::receiveNoteOn(const int channel, const int pitch, const int velocity) {
	cout << "OF: note: " << channel << " " << pitch << " " << velocity << endl;
}

void AppCore::receiveControlChange(const int channel, const int controller, const int value) {
	cout << "OF: ctl: " << channel << " " << controller << " " << value << endl;
}

void AppCore::receiveProgramChange(const int channel, const int value) {
	cout << "OF: pgm: " << channel << " " << value << endl;
}

void AppCore::receivePitchBend(const int channel, const int value) {
	cout << "OF: bend: " << channel << " " << value << endl;
}

void AppCore::receiveAftertouch(const int channel, const int value) {
	cout << "OF: touch: " << channel << " " << value << endl;
}

void AppCore::receivePolyAftertouch(const int channel, const int pitch, const int value) {
	cout << "OF: polytouch: " << channel << " " << pitch << " " << value << endl;
}

void AppCore::receiveMidiByte(const int port, const int byte) {
	cout << "OF: midibyte: " << port << " " << byte << endl;
}

void AppCore::touchDown(ofTouchEventArgs &touch) {
	if (pulsanti[0].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        page = pageDefault;
		pd.sendFloat("sezione", pulsanti[0].getId());
	}
	else if (pulsanti[1].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        if (pulsanti[1].isSelected()) {
            page = pagePitchPressed;
			pulsanti[14].setSelected(!switchScala);
			pulsanti[15].setSelected(switchScala);
			offSetBtnScala = 0;
	    }
	    else {
			page = pageDefault;
		}
	    pd.sendFloat("sezione", pulsanti[1].getId());
	}
	else if (pulsanti[2].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        page = pageDefault;
		pd.sendFloat("sezione", pulsanti[2].getId());
	}
	else if (pulsanti[3].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        page = pageDefault;
		pd.sendFloat("sezione", pulsanti[3].getId());
	}
	else if (pulsanti[4].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        if (pulsanti[4].isSelected()) {
            page = pagePitchPressed;
			pulsanti[14].setSelected(!switchScala);
			pulsanti[15].setSelected(switchScala);
			offSetBtnScala = 3 * (pulsanteHeight + distY_Pulsanti);
	    }
	    else {
			page = pageDefault;
		}
		pd.sendFloat("sezione", pulsanti[4].getId());
	}
	else if (pulsanti[5].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        imgSfondoBack = pulsanti[5].getImg();
		indexSfondo = Montagna;
	}
	else if (pulsanti[6].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        imgSfondoBack = pulsanti[6].getImg();
		indexSfondo = Mare;
    }
	else if (pulsanti[7].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        imgSfondoBack = pulsanti[7].getImg();
		indexSfondo = Egitto;
	}
	else if (pulsanti[8].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
        imgSfondoBack = pulsanti[8].getImg();
		indexSfondo = Citta;
	}
	else if (pulsanti[9].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (!pulsanti[9].isSelected()) {
			pd.sendBang("newSoglia");
			pulsanti[9].setSelected(true);
		}
	}
	else if (pulsanti[11].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (selectedButton != noSelectedButton) {
			pulsanti[selectedButton].setSelected(false);
			sole.setIntensita(0);
			selectedButton = noSelectedButton;
		}
		page = pageSetting;
	}
	else if (pulsanti[12].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    pulsanti[12].setSelected(true);
	    pd.sendBang("getTone");
	    toneTimer.setup(2000, false);
		selectedButton = pitchAnalisys;
		pd.sendFloat("sezione", pitchAnalisys);
		pd.sendFloat("switchScala", scalaAssoluta);
	}
	else if (pulsanti[13].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		page = pageDefault;
	}
	else if (pulsanti[14].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		switchScala = scalaAssoluta;
		pd.sendFloat("switchScala", switchScala);
		pulsanti[14].setSelected(!switchScala);
		pulsanti[15].setSelected(switchScala);
	}
	else if (pulsanti[15].pressedButton(touch.x, touch.y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		switchScala = scalaRelativa;
		pd.sendFloat("switchScala", switchScala);
		pulsanti[14].setSelected(!switchScala);
		pulsanti[15].setSelected(switchScala);
	}
}

void AppCore::mousePressed(int x, int y, int button) {
	if (pulsanti[0].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    page = pageDefault;
		pd.sendFloat("sezione", pulsanti[0].getId());
	}
	else if (pulsanti[1].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    if (pulsanti[1].isSelected()) {
            page = pagePitchPressed;
			pulsanti[14].setSelected(!switchScala);
			pulsanti[15].setSelected(switchScala);
			offSetBtnScala = 0;
	    }
	    else {
			page = pageDefault;
		}
	    pd.sendFloat("sezione", pulsanti[1].getId());
	}
	else if (pulsanti[2].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    page = pageDefault;
		pd.sendFloat("sezione", pulsanti[2].getId());
	}
	else if (pulsanti[3].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    page = pageDefault;
		pd.sendFloat("sezione", pulsanti[3].getId());
	}
	else if (pulsanti[4].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (pulsanti[4].isSelected()) {
            page = pagePitchPressed;
			pulsanti[14].setSelected(!switchScala);
			pulsanti[15].setSelected(switchScala);
			offSetBtnScala = 3 * (pulsanteHeight + distY_Pulsanti);
	    }
	    else {
			page = pageDefault;
		}
		pd.sendFloat("sezione", pulsanti[4].getId());
	}
	else if (pulsanti[5].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		imgSfondoBack = pulsanti[5].getImg();
		indexSfondo = Montagna;
	}
	else if (pulsanti[6].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		imgSfondoBack = pulsanti[6].getImg();
		indexSfondo = Mare;
	}
	else if (pulsanti[7].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		imgSfondoBack = pulsanti[7].getImg();
		indexSfondo = Egitto;
	}
	else if (pulsanti[8].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		imgSfondoBack = pulsanti[8].getImg();
		indexSfondo = Citta;
	}
	else if (pulsanti[9].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (!pulsanti[9].isSelected()) {
			pd.sendBang("newSoglia");
			pulsanti[9].setSelected(true);
		}
	}
	/*else if (pulsanti[10].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (ofGetWindowMode() == OF_WINDOW) ofSetFullscreen(true);
		else ofSetFullscreen(false);
	}*/
	else if (pulsanti[11].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		if (selectedButton != noSelectedButton) {
			pulsanti[selectedButton].setSelected(false);
			sole.setIntensita(0);
			selectedButton = noSelectedButton;
		}
		page = pageSetting;
	}
	else if (pulsanti[12].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
	    pulsanti[12].setSelected(true);
	    pd.sendBang("getTone");
	    toneTimer.setup(2000, false);
		selectedButton = pitchAnalisys;
		pd.sendFloat("sezione", pitchAnalisys);
		pd.sendFloat("switchScala", scalaAssoluta);
	}
	else if (pulsanti[13].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		page = pageDefault;
	}
	else if (pulsanti[14].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		switchScala = scalaAssoluta;
		pd.sendFloat("switchScala", switchScala);
		pulsanti[14].setSelected(!switchScala);
		pulsanti[15].setSelected(switchScala);
	}
	else if (pulsanti[15].pressedButton(x, y, &selectedButton, pulsanti[selectedButton], pd, sole)){
		switchScala = scalaRelativa;
		pd.sendFloat("switchScala", switchScala);
		pulsanti[14].setSelected(!switchScala);
		pulsanti[15].setSelected(switchScala);
	}
}

void AppCore::onToneTimerReached(ofEventArgs &args) {
    pulsanti[12].setSelected(false);
    pd.sendBang("getTone");
	selectedButton = noSelectedButton;
	pd.sendFloat("switchScala", switchScala);
}


