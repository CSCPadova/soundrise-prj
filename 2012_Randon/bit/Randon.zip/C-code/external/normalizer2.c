/*
 *  normalizer2.c
 *  SoundRise_iOS
 *
 *  Created by Marco Randon on 09/03/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */


#include "m_pd.h"
#include <math.h>

static t_class *normalizer2_class = (t_class*) NULL;

typedef struct _normalizer2 {
	t_object parent;	//this must be first MANDATORILY
	t_outlet *outlet1;
	t_float param2;		//store inlet2 value
	t_float param3;		//store inlet3 value
} t_normalizer2;

static t_normalizer2 *normalizer2_new(void) {
	t_normalizer2 *norm = (t_normalizer2*)pd_new(normalizer2_class);
	norm->outlet1 = outlet_new(&norm->parent, gensym("float"));
	norm->param2 = 0;
	norm->param3 = 0;
	floatinlet_new(&norm->parent, &norm->param2);
	floatinlet_new(&norm->parent, &norm->param3);
	return norm;
}

static void normalizer2_float(t_normalizer2 *norm, t_floatarg num) {
	outlet_float(norm->outlet1, pow(norm->param2 - num, 2) + pow(norm->param3, 2));
}

static void normalizer2_destroy(void) {
}

void normalizer2_setup(void) {
	normalizer2_class = class_new(gensym("normalizer2"), (t_newmethod)normalizer2_new, (t_method)normalizer2_destroy, sizeof(t_normalizer2), CLASS_DEFAULT, A_NULL);
	class_addfloat(normalizer2_class, (t_method)normalizer2_float);
}