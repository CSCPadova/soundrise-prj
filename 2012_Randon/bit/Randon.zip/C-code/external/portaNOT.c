/*
 *  porta_not.c
 *  SoundRise_iOS
 *
 *  Created by Marco Randon on 08/03/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */

#include "m_pd.h"

static t_class *portaNOT_class = (t_class*) NULL;

typedef struct _portaNOT {
	t_object parent;	//this must be first MANDATORILY
	t_outlet *outlet1;
} t_portaNOT;

static void portaNOT_float(t_portaNOT *p, t_floatarg num) {
	if (num) outlet_float(p->outlet1, 0.f);
	else outlet_float(p->outlet1, 1.f);
}

static void *portaNOT_new(void) {
	t_portaNOT *p = (t_portaNOT*)pd_new(portaNOT_class);
	p->outlet1 = outlet_new(&p->parent, 0);
	return(p);
}

static void portaNOT_destroy(void) {
}

void portaNOT_setup(void) {
	portaNOT_class = class_new(gensym("portaNOT"), (t_newmethod)portaNOT_new, (t_method)portaNOT_destroy, sizeof(t_portaNOT), CLASS_DEFAULT, A_NULL);
	class_addfloat(portaNOT_class, (t_method)portaNOT_float);
}