/*

featureAccum - an external for accumulating multiple feature frames over time.

Copyright 2010 William Brent

This file is part of timbreID.

timbreID is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

timbreID is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

version 0.0.2, December 20, 2010

� 0.0.2 as part of the timbreID-0.5 update, this gets rid of unnecessary getbytes(0) calls and uses memset() or memcpy() where possible

*/


#include "m_pd.h"

static t_class *featureAccum_class;

typedef struct instance
{
    float *instance;
} t_instance;

typedef struct _featureAccum
{
	t_object  x_obj;
    t_instance *instances;
	int feature_length;
	int num_frames;
	int current_frame;
    t_outlet *feature_list;
} t_featureAccum;


static void featureAccum_accum(t_featureAccum *x, t_symbol *s, int argc, t_atom *argv)
{
	int i, j, totalfeat;
	t_atom *list_out;
	s=s;
	
	if(x->feature_length != argc)
		error("featureAccum: input length does not match current length setting. input ignored.");
	else
		for(i=0; i<x->feature_length; i++)
			x->instances[x->current_frame].instance[i] = atom_getfloat(argv+i);
	
	x->current_frame++;
	
	if(x->current_frame==x->num_frames)
	{
		totalfeat = x->feature_length * x->num_frames;
		
		// create local memory
		list_out = (t_atom *)getbytes(totalfeat*sizeof(t_atom));

		for(i=0; i<x->num_frames; i++)
			for(j=0; j<x->feature_length; j++)
				SETFLOAT(list_out+(i*x->feature_length)+j, x->instances[i].instance[j]);

		outlet_list(x->feature_list, 0, totalfeat, list_out);
		
		x->current_frame = 0;

		// free local memory
		t_freebytes(list_out, totalfeat*sizeof(t_atom));
	}
}

static void featureAccum_clear(t_featureAccum *x)
{
	int i;

	// free the database memory
	for(i=0; i<x->num_frames; i++)
		t_freebytes(x->instances[i].instance, x->feature_length*sizeof(float));
	
	t_freebytes(x->instances, x->num_frames*sizeof(t_instance));
	
	x->current_frame = 0;
    
    x->instances = (t_instance *)getbytes(x->num_frames*sizeof(t_instance));
	
	for(i=0; i<x->num_frames; i++)
		x->instances[i].instance = (float *)getbytes(x->feature_length*sizeof(float));
}

static void featureAccum_num_frames(t_featureAccum *x, t_float num)
{
	int i;
	
	if(num)
	{
		// free the database memory
		for(i=0; i<x->num_frames; i++)
			t_freebytes(x->instances[i].instance, x->feature_length*sizeof(float));
		
		t_freebytes(x->instances, x->num_frames*sizeof(t_instance));
		
		x->current_frame = 0;
		
		x->num_frames = num;

		x->instances = (t_instance *)getbytes(x->num_frames*sizeof(t_instance));
		
		for(i=0; i<x->num_frames; i++)
			x->instances[i].instance = (float *)getbytes(x->feature_length*sizeof(float));
	}
}

static void featureAccum_length(t_featureAccum *x, t_float len)
{
	int i;
	
	if(len)
	{
		// free the database memory
		for(i=0; i<x->num_frames; i++)
			t_freebytes(x->instances[i].instance, x->feature_length*sizeof(float));
		
		t_freebytes(x->instances, x->num_frames*sizeof(t_instance));
				
		x->instances = (t_instance *)getbytes(x->num_frames*sizeof(t_instance));    	

		x->feature_length = len;
		x->current_frame = 0;

		for(i=0; i<x->num_frames; i++)
			x->instances[i].instance = (float *)getbytes(x->feature_length*sizeof(float));
	}
}

static void *featureAccum_new(t_float num_frames, t_float length)
{
	t_featureAccum *x = (t_featureAccum *)pd_new(featureAccum_class);	
	int i;

	x->feature_list = outlet_new(&x->x_obj, gensym("list"));

	x->feature_length = length;
	x->num_frames = num_frames;
	x->current_frame = 0;
	
    x->instances = (t_instance *)getbytes(x->num_frames*sizeof(t_instance));

	for(i=0; i<x->num_frames; i++)
		x->instances[i].instance = (float *)getbytes(x->feature_length*sizeof(float));
	
	return (void *)x;
}

static void featureAccum_free(t_featureAccum *x)
{
	int i;

	// free the database memory
	for(i=0; i<x->num_frames; i++)
		t_freebytes(x->instances[i].instance, x->feature_length*sizeof(float));
	
	t_freebytes(x->instances, x->num_frames*sizeof(t_instance));
	
}

void featureAccum_setup(void) {

	featureAccum_class = class_new(gensym("featureAccum"),
		(t_newmethod)featureAccum_new,
		(t_method)featureAccum_free,
		sizeof(t_featureAccum),
		CLASS_DEFAULT,
		A_DEFFLOAT,
		A_DEFFLOAT,
		0
	);

	class_addlist(featureAccum_class, featureAccum_accum);

	class_addmethod(
		featureAccum_class, 
        (t_method)featureAccum_accum,
		gensym("accum"),
        A_GIMME,
		0
	);
	
	class_addmethod(
		featureAccum_class, 
        (t_method)featureAccum_clear,
		gensym("clear"),
		0
	);

	class_addmethod(
		featureAccum_class, 
        (t_method)featureAccum_num_frames,
		gensym("num_frames"),
		A_DEFFLOAT,
		0
	);
	
	class_addmethod(
		featureAccum_class, 
        (t_method)featureAccum_length,
		gensym("length"),
		A_DEFFLOAT,
		0
	);
}