/*
 *  isteresi.c
 *  SoundRise_iOS
 *
 *  Created by Marco Randon on 08/03/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */


#include "m_pd.h"

#define LOW 0
#define HIGH 1

static t_class *isteresi_class = (t_class*) NULL;

typedef struct _isteresi {
	t_object parent;	//this must be first MANDATORILY
	t_outlet *outlet1;	//bang output for upper thresh
	t_outlet *outlet2;	//bang output for lower thresh
	t_clock *clock;		//wakeup for message output
	int state;			//low = 0, high = 1
	float highValue;
	float lowValue;
	float deadWait;		//ms remaining in dead period
	float highDeadTime;
	float lowDeadTime;
} t_isteresi;

static void isteresi_tick(t_isteresi *ist);
static void isteresi_set(t_isteresi *ist, t_floatarg highValue, t_floatarg highDeadTime, t_floatarg lowValue, t_floatarg lowDeadTime);

static t_isteresi *isteresi_new(t_floatarg highValue, t_floatarg highDeadTime, t_floatarg lowValue, t_floatarg lowDeadTime) {
	t_isteresi *ist = (t_isteresi*)pd_new(isteresi_class);
	ist->state = LOW;
	ist->deadWait = 0;	//no dead time
	ist->outlet1 = outlet_new(&ist->parent, gensym("bang"));
	ist->outlet2 = outlet_new(&ist->parent, gensym("bang"));
	ist->clock = clock_new(ist, (t_method)isteresi_tick);
	isteresi_set(ist, highValue, highDeadTime, lowValue, lowDeadTime);
	return (ist);
}

static void isteresi_set(t_isteresi *ist, t_floatarg highValue, t_floatarg highDeadTime, t_floatarg lowValue, t_floatarg lowDeadTime) {
	if (highValue < lowValue) lowValue = highValue;
	ist->highValue = highValue;
	ist->lowValue = lowValue;
	ist->highDeadTime = highDeadTime;
	ist->lowDeadTime = lowDeadTime;
}

static void isteresi_ft1(t_isteresi *ist, t_floatarg num) {
	ist->state = (num != 0);
	ist->deadWait = 0;
}

static void isteresi_float(t_isteresi *ist, t_float num) {
	if (ist->deadWait > 0) ist->deadWait -= 1;
	else if (ist->state) {
		if (num < ist->lowValue) {
			clock_delay(ist->clock, 0L);
			ist->state = LOW;
			ist->deadWait = ist->lowDeadTime;
		}
	} else {
		if (num >= ist->highValue) {
			clock_delay(ist->clock, 0L);
			ist->state = HIGH;
			ist->deadWait = ist->highDeadTime;
		}
	}
}

static void isteresi_tick(t_isteresi *ist) {
	if (ist->state) outlet_bang(ist->outlet1);
	else outlet_bang(ist->outlet2);
}

static void isteresi_destroy(t_isteresi *ist) {
	clock_free(ist->clock);
}

void isteresi_setup(void) {
	isteresi_class = class_new(gensym("isteresi"), (t_newmethod)isteresi_new, (t_method)isteresi_destroy, sizeof(t_isteresi), CLASS_DEFAULT, A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, A_NULL);
	class_addfloat(isteresi_class, (t_method)isteresi_float);
	class_addmethod(isteresi_class, (t_method)isteresi_set, gensym("set"), A_FLOAT, A_FLOAT, A_FLOAT, A_FLOAT, A_NULL);
	class_addmethod(isteresi_class, (t_method)isteresi_ft1, gensym("ft1"), A_FLOAT, 0);
}
